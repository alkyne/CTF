#!/usr/bin/python
#  -*- coding: utf-8 -*-
import string
import os
from datetime import datetime
import commands
import hashlib, sys
import glob
import sqlite3

#Get Stat
def get_stat(path):
    stat = commands.getoutput('stat ' + path)
    return stat

#Calculate MD5 Hash
def md5_hash(path):
	f=open(path, 'rb')
	return hashlib.md5(f.read()).hexdigest()

#Calculate SHA1 Hash
def sha1_hash(path):
	f=open(path, 'rb')
	return hashlib.sha1(f.read()).hexdigest()

#Physical Memory Dump Function
def pyhsical_memory_dump(current_path,path):
	os.system('chmod -R 777 ' + current_path + '/Physical\ Memory/')
	os.chdir(current_path + '/Physical Memory/')
	os.system('./MacMemoryReader -H MD5 -H SHA-1 ' + path + 'MemoryDump 2>' + path + 
		'MemoryDump.log')

#Live Status Aquire Function
def live_status_aquire(current_path,path):
	#live_status_command File을 줄 단위로 Read
	live_status = open(current_path + '/live_status_command','rb').readlines()
	'''
	live_status_command 내용 Format : Directory : Directory 명
								 	 -Directory : Directory 명
								 	 명령어 \t File 명
	'''
	#Live 상태 정보 수집 실행
	for i in range(len(live_status)):
	
		#live_status_command File 내에 구분 편하도록 ===== 로 수집 정보 분류
		if '=====' in live_status[i]:
			pass

		#분류 나누기 위해 Directory 생성
		elif 'Directory' in live_status[i]:
			
			if '-' not in live_status[i]:#1차 분류 Directory
				directory1 = path + (live_status[i].split(' : ')[1].replace('\n','')) + '/'
				information_dir = directory1
			elif '-' in live_status[i] :#2차 분류 Directory
				information_dir = directory1 + (live_status[i].split(' : ')[1].replace('\n','')) + '/'
			
			#Directory 없을 경우 생성
			if not os.path.exists(information_dir):
				os.makedirs(information_dir)
			else :
				pass
			
			#수집할 Directory로 위치 이동
			os.chdir(information_dir)

		#명령어 수행
		elif 'Directory' not in live_status[i]:
			command = str(live_status[i].split('\t')[0])
			command_info = str(live_status[i].split('\t')[1].replace(' ','\\ ').replace('\n',''))
			aquire_file = str(command_info + '.txt')
			os.system(command + ' 2>/dev/null > ' + aquire_file)#실제 명령 수행 부분

#Artifacts Aquire Function
def artifacts_aquire(current_path,path,home):
	#artifacts_list File을 줄 단위로 Read
	artifacts = open(current_path + '/artifacts_list','rb').readlines()
	'''
	artifacts_list 내용 Format : Directory : Directory 명
								 -Directory : Directory 명
								 ++Directory : Directory 명
								 ++File 경로 \t File 명
								 File 경로 \t File 명
								 command : 명령어 \t File 명
	'''
	#Artifacts 정보 수집 실행
	for i in range(len(artifacts)):
		
		#절대 경로로 변환
		if artifacts[i].startswith('~'):
			artifacts[i] = home + artifacts[i].replace('~','')

		#artifacts_list File 내에 구분 편하도록 ===== 로 수집 정보 분류
		if '=====' in artifacts[i]:
			continue
		
		#분류 나누기 위해 Directory 생성
		elif 'Directory' in artifacts[i]:
			
			if not artifacts[i].startswith('-') and not artifacts[i].startswith('++'):#1차 분류 Directory
				directory1 = path + (artifacts[i].split(' : ')[1].replace('\n','')) + '/'
				information_dir = directory1
				print '----' + artifacts[i].split(' : ')[1].replace('\n','') + ' 수집'
			elif artifacts[i].startswith('-'):#2차 분류 Directory
				directory2 = directory1 + (artifacts[i].split(' : ')[1].replace('\n','')) + '/'
				information_dir = directory2
			elif artifacts[i].startswith('++'):#3차 분류 Directory
				information_dir = directory2 + (artifacts[i].split(' : ')[1].replace('\n','')) + '/'

			#Directory 없을 경우 생성
			if not os.path.exists(information_dir):
				os.makedirs(information_dir)
			else :
				continue
			
			#수집할 Directory로 위치 이동
			os.chdir(information_dir)
			
		#Artifacts 수집 수행
		elif 'Directory' not in artifacts[i]:
			if not artifacts[i].startswith('command'):#복사 수행
				artifact_item = str(artifacts[i].split('\t')[0]).replace(' ','\\ ')
				artifact_info = str(artifacts[i].split('\t')[1].replace(' ','\\ ').replace('\n','')) 
				aquire_file = str(artifact_info)
				if artifacts[i].startswith('#'): #Directory 채로 복사
					artifact_item = artifact_item.replace('#','')

					if '*' in artifact_item:#Directory 내부 특정 확장자 형태의 Artifact의 경우 SQLite Insert Item
						artifact_item_list = glob.glob(artifact_item)
						if not artifact_item_list:#Directory 내부 특정 확장자 존재 여부 확인
							os.chdir('../')
							continue
						for search_item in artifact_item_list:#Directory 내부 특정 확장자 File들을 Insert
							make_insert_data_list(search_item.split('/')[-1],search_item)#SQLite Insert List
					elif artifact_item.endswith('/'):#Directory 내부 Artifact의 경우 SQLite Insert Item
						if not os.path.isdir(artifact_item):#Directory 존재 여부 확인
							os.chdir('../')
							continue
						file_search(artifact_item)#Directory 내부 File들을 Insert

					os.system('cp -R ' + artifact_item + ' ./ 2>/dev/null')
					os.chdir('../')

				elif not artifacts[i].startswith('#'): #File만 복사
					if not os.path.isfile(artifact_item):#File 존재 여부 확인
						continue
					make_insert_data_list(aquire_file,artifact_item)#SQLite Insert List
					os.system('cp -R ' + artifact_item + ' ' + aquire_file + ' 2>/dev/null')

			elif artifacts[i].startswith('command'):#명령어 수행
				artifacts[i] = artifacts[i].split(' : ')[1]
				command = str(artifacts[i].split('\t')[0])
				command_info = str(artifacts[i].split('\t')[1].replace(' ','\\ ').replace('\n',''))
				aquire_file = str(command_info + '.txt')
				os.system(command + ' > ' + aquire_file)#실제 명령 수행 부분

#하위 Directory 계산
def file_search(path):
	file_list = os.listdir(path)
	for f in file_list:
		searched_file = os.path.join(path, f)
		if os.path.isdir(searched_file):
			file_search(searched_file)
		else:
			make_insert_data_list(searched_file.split('/')[-1],searched_file)

#SQLite에 Insert 할 Data List 생성
def make_insert_data_list(file_name,searched_file):
	permission = get_stat(searched_file).split(' ')[2]
	uid = get_stat(searched_file).split(' ')[4]
	guid = get_stat(searched_file).split(' ')[5]
	file_size = get_stat(searched_file).split(' ')[7]
	atime = get_stat(searched_file).split('"')[1]
	mtime = get_stat(searched_file).split('"')[3]
	ctime = get_stat(searched_file).split('"')[5]
	birthtime = get_stat(searched_file).split('"')[7]

	item = (file_name, permission, uid, guid, file_size, atime, mtime, ctime, birthtime, md5_hash(searched_file), sha1_hash(searched_file))
	insert_list.append(item)

#SQLite File 생성
def create_sqlite(db_name,insert_list):
	conn = sqlite3.connect(db_name)
	conn.text_factory = str
	c = conn.cursor()
	c.execute("CREATE TABLE artifacts (File_Name, Permission, UID, GUID, File_Size, Access Time, Modify Time, Change Time, Birth Time, MD5, SHA1)")
	c.executemany("INSERT INTO artifacts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", insert_list)
	conn.commit()
	conn.close()

#기본 정보
case_name = raw_input("Case Name : ")
case_exam = raw_input("Case Examination : ")
path = raw_input("Aquire Path(Absolute) : ")
aquire_time = datetime.today()#수집 시간
current_path = str(os.getcwd())#현재 경로
home = commands.getoutput('echo $HOME')#User Home Directory 

#경로 처리
if not path.startswith('/'):
	path = '/' + path
if not path.endswith('/'):
	path = path + '/'
path = path + case_name + '/'#Case 명으로 Directory 생성

#Directory 없을 경우 생성
if not os.path.exists(path):
	os.makedirs(path)
else :
	pass

#변수 선언
information_dir = ''#실제 정보가 저장될 Directory
artifact_item_list= [] #Directory 형식의 Artifact일 경우
insert_list = []#sqlite에 저장될 List

#실제 기능 수행 부분
#Screen Capture
os.system("screencapture " + path + str(aquire_time).replace(' ','\\ ') + ".png")

#Physical Memory Dump
print '[+] Physical Memory Dump 진행 중'
pyhsical_memory_dump(current_path,path)
print '[+] Physical Memory Dump 완료'

#Live Status Aquire
print '[+] Live 상태 정보 수집 중'
live_status_aquire(current_path,path)
print '[+] Live 상태 정보 수집 완료'

#Artifacts Aquire
print '[+] Artifacts 수집 중'
artifacts_aquire(current_path,path,home)
print '[+] Artifacts 수집 완료'

#SQLite file 생성
print '[+] SQLite File 생성 중'
create_sqlite(path + 'artifacts_list.db',insert_list)
print '[+] SQLite File 생성 완료'